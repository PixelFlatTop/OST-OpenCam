# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "manacamsys",
    "author" : " by Carlos Paris (Pixelflatop)", 
    "description" : "Panel for ticking the camera properties",
    "blender" : (4, 0, 0),
    "version" : (0, 0, 3),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "User Interface" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
visual_scripting_editor = {'sna_new_variable': False, }


def sna_camera_controllers_AB710(layout_function, ):
    box_63FAD = layout_function.box()
    box_63FAD.alert = False
    box_63FAD.enabled = True
    box_63FAD.active = True
    box_63FAD.use_property_split = False
    box_63FAD.use_property_decorate = False
    box_63FAD.alignment = 'Expand'.upper()
    box_63FAD.scale_x = 1.0
    box_63FAD.scale_y = 1.0
    if not True: box_63FAD.operator_context = "EXEC_DEFAULT"
    row_B4342 = box_63FAD.row(heading='', align=False)
    row_B4342.alert = False
    row_B4342.enabled = True
    row_B4342.active = True
    row_B4342.use_property_split = False
    row_B4342.use_property_decorate = False
    row_B4342.scale_x = 1.0
    row_B4342.scale_y = 1.0
    row_B4342.alignment = 'Expand'.upper()
    row_B4342.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_B4342.prop(bpy.context.scene, 'sna_controllers', text='', icon_value=(5 if bpy.context.scene.sna_controllers else 4), emboss=False)
    row_B4342.label(text='CAMERA CONTROLLERS', icon_value=256)
    if bpy.context.scene.sna_controllers:
        col_52068 = box_63FAD.column(heading='', align=False)
        col_52068.alert = False
        col_52068.enabled = True
        col_52068.active = True
        col_52068.use_property_split = False
        col_52068.use_property_decorate = False
        col_52068.scale_x = 1.0
        col_52068.scale_y = 1.0
        col_52068.alignment = 'Expand'.upper()
        col_52068.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_CC640 = col_52068.row(heading='', align=False)
        row_CC640.alert = False
        row_CC640.enabled = True
        row_CC640.active = True
        row_CC640.use_property_split = False
        row_CC640.use_property_decorate = False
        row_CC640.scale_x = 1.1799999475479126
        row_CC640.scale_y = 1.1799999475479126
        row_CC640.alignment = 'Expand'.upper()
        row_CC640.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_CC640.operator('object.select_camera', text='Select Active Camera', icon_value=168, emboss=True, depress=False)
        op.extend = True
        col_52068.separator(factor=0.8799999952316284)
        row_5E5DC = col_52068.row(heading='', align=False)
        row_5E5DC.alert = False
        row_5E5DC.enabled = True
        row_5E5DC.active = True
        row_5E5DC.use_property_split = False
        row_5E5DC.use_property_decorate = False
        row_5E5DC.scale_x = 1.0
        row_5E5DC.scale_y = 1.0
        row_5E5DC.alignment = 'Center'.upper()
        row_5E5DC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_D622D = row_5E5DC.box()
        box_D622D.alert = False
        box_D622D.enabled = True
        box_D622D.active = True
        box_D622D.use_property_split = False
        box_D622D.use_property_decorate = False
        box_D622D.alignment = 'Expand'.upper()
        box_D622D.scale_x = 2.5
        box_D622D.scale_y = 0.6399999856948853
        if not True: box_D622D.operator_context = "EXEC_DEFAULT"
        box_D622D.label(text='Bones Clearing', icon_value=256)
        col_52068.separator(factor=0.5799999237060547)
        grid_F4956 = col_52068.grid_flow(columns=2, row_major=True, even_columns=True, even_rows=False, align=False)
        grid_F4956.enabled = True
        grid_F4956.active = True
        grid_F4956.use_property_split = True
        grid_F4956.use_property_decorate = False
        grid_F4956.alignment = 'Center'.upper()
        grid_F4956.scale_x = 1.5399999618530273
        grid_F4956.scale_y = 1.3600000143051147
        if not True: grid_F4956.operator_context = "EXEC_DEFAULT"
        op = grid_F4956.operator('pose.transforms_clear', text='Clear All', icon_value=0, emboss=True, depress=False)
        op = grid_F4956.operator('pose.loc_clear', text='Clear Location', icon_value=0, emboss=True, depress=False)
        op = grid_F4956.operator('pose.rot_clear', text='Clear Rotation', icon_value=0, emboss=True, depress=False)
        op = grid_F4956.operator('pose.scale_clear', text='Clear Scale', icon_value=0, emboss=True, depress=False)


def sna_camerasettings_6F085(layout_function, ):
    box_507C8 = layout_function.box()
    box_507C8.alert = False
    box_507C8.enabled = True
    box_507C8.active = True
    box_507C8.use_property_split = False
    box_507C8.use_property_decorate = False
    box_507C8.alignment = 'Expand'.upper()
    box_507C8.scale_x = 1.0
    box_507C8.scale_y = 1.0
    if not True: box_507C8.operator_context = "EXEC_DEFAULT"
    row_E2E19 = box_507C8.row(heading='', align=False)
    row_E2E19.alert = False
    row_E2E19.enabled = True
    row_E2E19.active = True
    row_E2E19.use_property_split = False
    row_E2E19.use_property_decorate = False
    row_E2E19.scale_x = 1.0
    row_E2E19.scale_y = 1.0
    row_E2E19.alignment = 'Expand'.upper()
    row_E2E19.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_E2E19.prop(bpy.context.scene, 'sna_camera_setting_toggle', text='', icon_value=(5 if bpy.context.scene.sna_camera_setting_toggle else 4), emboss=False)
    row_E2E19.label(text='CAMERA SETTINGS', icon_value=192)
    if bpy.context.scene.sna_camera_setting_toggle:
        col_E442A = box_507C8.column(heading='', align=True)
        col_E442A.alert = False
        col_E442A.enabled = (bpy.context.scene.camera != None)
        col_E442A.active = True
        col_E442A.use_property_split = True
        col_E442A.use_property_decorate = False
        col_E442A.scale_x = 1.0
        col_E442A.scale_y = 1.0
        col_E442A.alignment = 'Expand'.upper()
        col_E442A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_43505 = col_E442A.box()
        box_43505.alert = False
        box_43505.enabled = True
        box_43505.active = True
        box_43505.use_property_split = True
        box_43505.use_property_decorate = False
        box_43505.alignment = 'Expand'.upper()
        box_43505.scale_x = 1.0
        box_43505.scale_y = 0.7000000476837158
        if not True: box_43505.operator_context = "EXEC_DEFAULT"
        row_6153F = box_43505.row(heading='', align=True)
        row_6153F.alert = False
        row_6153F.enabled = True
        row_6153F.active = True
        row_6153F.use_property_split = True
        row_6153F.use_property_decorate = False
        row_6153F.scale_x = 1.0
        row_6153F.scale_y = 1.059999942779541
        row_6153F.alignment = 'Center'.upper()
        row_6153F.operator_context = "INVOKE_DEFAULT" if False else "EXEC_DEFAULT"
        row_6153F.label(text='CAMERA NAME', icon_value=0)
        col_E442A.separator(factor=-0.25999999046325684)
        row_F39E2 = col_E442A.row(heading='', align=True)
        row_F39E2.alert = False
        row_F39E2.enabled = True
        row_F39E2.active = True
        row_F39E2.use_property_split = True
        row_F39E2.use_property_decorate = False
        row_F39E2.scale_x = 1.9900000095367432
        row_F39E2.scale_y = 1.2699999809265137
        row_F39E2.alignment = 'Expand'.upper()
        row_F39E2.operator_context = "INVOKE_DEFAULT" if False else "EXEC_DEFAULT"
        row_F39E2.prop(bpy.context.view_layer.objects.active, 'name', text='', icon_value=0, emboss=True)
        col_E442A.separator(factor=1.3899998664855957)
        row_CCDFA = col_E442A.row(heading='', align=False)
        row_CCDFA.alert = False
        row_CCDFA.enabled = True
        row_CCDFA.active = True
        row_CCDFA.use_property_split = False
        row_CCDFA.use_property_decorate = False
        row_CCDFA.scale_x = 1.0
        row_CCDFA.scale_y = 1.0
        row_CCDFA.alignment = 'Expand'.upper()
        row_CCDFA.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_CCDFA.prop(bpy.data.cameras[0], 'lens', text='Lens mm', icon_value=0, emboss=True)
        row_F71F2 = col_E442A.row(heading='', align=False)
        row_F71F2.alert = False
        row_F71F2.enabled = True
        row_F71F2.active = True
        row_F71F2.use_property_split = False
        row_F71F2.use_property_decorate = False
        row_F71F2.scale_x = 1.0
        row_F71F2.scale_y = 1.0
        row_F71F2.alignment = 'Expand'.upper()
        row_F71F2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_F71F2.prop(bpy.data.cameras[0], 'clip_start', text='Clip Start', icon_value=0, emboss=True)
        row_F71F2.prop(bpy.data.cameras[0], 'clip_end', text='Clip End', icon_value=0, emboss=True)
        col_CCCB0 = col_E442A.column(heading='', align=False)
        col_CCCB0.alert = False
        col_CCCB0.enabled = True
        col_CCCB0.active = True
        col_CCCB0.use_property_split = False
        col_CCCB0.use_property_decorate = False
        col_CCCB0.scale_x = 1.0
        col_CCCB0.scale_y = 1.0
        col_CCCB0.alignment = 'Expand'.upper()
        col_CCCB0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_CCCB0.separator(factor=0.46000006794929504)
        col_CCCB0.prop(bpy.data.cameras[0].dof, 'use_dof', text='Use DOF', icon_value=0, emboss=True, toggle=True)
        if bpy.data.cameras[0].dof.use_dof:
            col_CCCB0.prop(bpy.data.cameras[0].dof, 'aperture_fstop', text='f-Stop', icon_value=0, emboss=False, toggle=False)
        if bpy.data.cameras[0].dof.use_dof:
            col_CCCB0.prop(bpy.data.cameras[0].dof, 'focus_distance', text='Focus Distance', icon_value=0, emboss=False)
        if bpy.data.cameras[0].dof.use_dof:
            col_CCCB0.prop(bpy.data.cameras[0], 'show_limits', text='Show Limits', icon_value=0, emboss=True, toggle=True)
        row_FAB36 = col_CCCB0.row(heading='', align=False)
        row_FAB36.alert = False
        row_FAB36.enabled = True
        row_FAB36.active = True
        row_FAB36.use_property_split = False
        row_FAB36.use_property_decorate = False
        row_FAB36.scale_x = 1.0
        row_FAB36.scale_y = 1.0
        row_FAB36.alignment = 'Expand'.upper()
        row_FAB36.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if bpy.data.cameras[0].dof.use_dof:
            if bpy.context.scene.sna_button:
                row_FAB36.prop(bpy.data.cameras[0].dof, 'focus_object', text='', icon_value=0, emboss=True)
        if bpy.data.cameras[0].dof.use_dof:
            row_FAB36.prop(bpy.context.scene, 'sna_button', text='Use Focus Object?', icon_value=0, emboss=True, toggle=True)


def sna_export__render_F6F8C(layout_function, ):
    box_EC4F7 = layout_function.box()
    box_EC4F7.alert = False
    box_EC4F7.enabled = True
    box_EC4F7.active = True
    box_EC4F7.use_property_split = False
    box_EC4F7.use_property_decorate = False
    box_EC4F7.alignment = 'Expand'.upper()
    box_EC4F7.scale_x = 1.0
    box_EC4F7.scale_y = 1.0
    if not True: box_EC4F7.operator_context = "EXEC_DEFAULT"
    row_E54E1 = box_EC4F7.row(heading='', align=False)
    row_E54E1.alert = False
    row_E54E1.enabled = True
    row_E54E1.active = True
    row_E54E1.use_property_split = False
    row_E54E1.use_property_decorate = False
    row_E54E1.scale_x = 1.0
    row_E54E1.scale_y = 1.0
    row_E54E1.alignment = 'Expand'.upper()
    row_E54E1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_E54E1.prop(bpy.context.scene, 'sna_export__render', text='', icon_value=(5 if bpy.context.scene.sna_export__render else 4), emboss=False)
    row_E54E1.label(text='Export / Render', icon_value=191)
    if bpy.context.scene.sna_export__render:
        col_14EC3 = box_EC4F7.column(heading='', align=False)
        col_14EC3.alert = False
        col_14EC3.enabled = True
        col_14EC3.active = True
        col_14EC3.use_property_split = False
        col_14EC3.use_property_decorate = False
        col_14EC3.scale_x = 1.0
        col_14EC3.scale_y = 1.090000033378601
        col_14EC3.alignment = 'Expand'.upper()
        col_14EC3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_7B228 = col_14EC3.row(heading='', align=True)
        row_7B228.alert = False
        row_7B228.enabled = True
        row_7B228.active = True
        row_7B228.use_property_split = False
        row_7B228.use_property_decorate = False
        row_7B228.scale_x = 1.4800000190734863
        row_7B228.scale_y = 1.4800000190734863
        row_7B228.alignment = 'Expand'.upper()
        row_7B228.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_7B228.operator('render.opengl', text='PLAYBLAST RENDER', icon_value=240, emboss=True, depress=False)
        op.animation = True
        row_AED00 = col_14EC3.row(heading='', align=True)
        row_AED00.alert = False
        row_AED00.enabled = True
        row_AED00.active = True
        row_AED00.use_property_split = False
        row_AED00.use_property_decorate = False
        row_AED00.scale_x = 1.4800000190734863
        row_AED00.scale_y = 1.4800000190734863
        row_AED00.alignment = 'Expand'.upper()
        row_AED00.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_AED00.operator('render.render', text='RENDER STILL', icon_value=258, emboss=True, depress=False)
        op.write_still = True
        op = row_AED00.operator('render.render', text='RENDER ANIMATION', icon_value=240, emboss=True, depress=False)
        op.animation = True
        op.write_still = True
        col_14EC3.separator(factor=1.0)
        col_14EC3.prop(bpy.context.scene.render, 'film_transparent', text='Transparent', icon_value=0, emboss=True, toggle=True)
        col_14EC3.separator(factor=1.3899999856948853)
        col_14EC3.prop(bpy.context.scene.render, 'filepath', text='File Path', icon_value=0, emboss=True)
        col_14EC3.prop(bpy.data.scenes[0].render.image_settings, 'file_format', text='', icon_value=0, emboss=True)
        col_14EC3.prop(bpy.context.scene, 'sna_display_ffmpeg_properties', text='Display FFmpeg Properties', icon_value=0, emboss=True, toggle=True)
        if bpy.context.scene.sna_display_ffmpeg_properties:
            grid_2770E = col_14EC3.grid_flow(columns=1, row_major=True, even_columns=False, even_rows=False, align=True)
            grid_2770E.enabled = True
            grid_2770E.active = True
            grid_2770E.use_property_split = True
            grid_2770E.use_property_decorate = False
            grid_2770E.alignment = 'Expand'.upper()
            grid_2770E.scale_x = 0.3700000047683716
            grid_2770E.scale_y = 1.2699999809265137
            if not True: grid_2770E.operator_context = "EXEC_DEFAULT"
            grid_2770E.separator(factor=0.5139999985694885)
            grid_2770E.prop(bpy.context.scene.render.ffmpeg, 'format', text='', icon_value=0, emboss=True)
            grid_2770E.separator(factor=0.009999990463256836)
            grid_2770E.prop(bpy.context.scene.render.ffmpeg, 'codec', text='', icon_value=0, emboss=True)
            grid_2770E.separator(factor=0.3190000057220459)
            grid_2770E.prop(bpy.context.scene.render.ffmpeg, 'constant_rate_factor', text='', icon_value=0, emboss=True)


def sna_linking_AB941(layout_function, ):
    box_E6958 = layout_function.box()
    box_E6958.alert = False
    box_E6958.enabled = True
    box_E6958.active = True
    box_E6958.use_property_split = True
    box_E6958.use_property_decorate = False
    box_E6958.alignment = 'Expand'.upper()
    box_E6958.scale_x = 1.0
    box_E6958.scale_y = 1.0
    if not True: box_E6958.operator_context = "EXEC_DEFAULT"
    row_5B047 = box_E6958.row(heading='', align=False)
    row_5B047.alert = False
    row_5B047.enabled = True
    row_5B047.active = True
    row_5B047.use_property_split = False
    row_5B047.use_property_decorate = False
    row_5B047.scale_x = 1.0
    row_5B047.scale_y = 1.0
    row_5B047.alignment = 'Expand'.upper()
    row_5B047.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_5B047.prop(bpy.context.scene, 'sna_linking', text='', icon_value=(5 if bpy.context.scene.sna_linking else 4), emboss=False)
    row_5B047.label(text='UTILITIES', icon_value=192)
    if bpy.context.scene.sna_linking:
        col_2E798 = box_E6958.column(heading='', align=False)
        col_2E798.alert = False
        col_2E798.enabled = True
        col_2E798.active = True
        col_2E798.use_property_split = False
        col_2E798.use_property_decorate = False
        col_2E798.scale_x = 1.0
        col_2E798.scale_y = 1.1799999475479126
        col_2E798.alignment = 'Expand'.upper()
        col_2E798.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_EA773 = col_2E798.row(heading='', align=False)
        row_EA773.alert = False
        row_EA773.enabled = True
        row_EA773.active = True
        row_EA773.use_property_split = False
        row_EA773.use_property_decorate = False
        row_EA773.scale_x = 1.0
        row_EA773.scale_y = 1.0
        row_EA773.alignment = 'Expand'.upper()
        row_EA773.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_EA773.operator('wm.link', text='Link', icon_value=56, emboss=True, depress=False)
        op = row_EA773.operator('wm.append', text='Append', icon_value=705, emboss=True, depress=False)
        op = col_2E798.operator('file.find_missing_files', text='Find Missing Files', icon_value=30, emboss=True, depress=False)
        op = col_2E798.operator('file.pack_all', text='Pack Data', icon_value=179, emboss=True, depress=False)
        row_3522D = col_2E798.row(heading='', align=False)
        row_3522D.alert = False
        row_3522D.enabled = True
        row_3522D.active = True
        row_3522D.use_property_split = False
        row_3522D.use_property_decorate = False
        row_3522D.scale_x = 1.0
        row_3522D.scale_y = 1.0
        row_3522D.alignment = 'Expand'.upper()
        row_3522D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_3522D.operator('file.pack_libraries', text='Pack Linked', icon_value=41, emboss=True, depress=False)
        op = row_3522D.operator('file.unpack_libraries', text='Unpack Linked', icon_value=40, emboss=True, depress=False)
        col_2E798.separator(factor=1.0)
        op = col_2E798.operator('outliner.orphans_purge', text='Clean Unused Data', icon_value=0, emboss=True, depress=False)


class SNA_OT_My_Generic_Operator_0Ad3C(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_0ad3c"
    bl_label = "1.35:1"
    bl_description = "1920 x 1443 HD "
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1443
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_E6008(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_e6008"
    bl_label = "16:9"
    bl_description = "1920 x 1080 HD "
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_resolution_843C4(layout_function, ):
    box_E9A8A = layout_function.box()
    box_E9A8A.alert = False
    box_E9A8A.enabled = True
    box_E9A8A.active = True
    box_E9A8A.use_property_split = True
    box_E9A8A.use_property_decorate = False
    box_E9A8A.alignment = 'Expand'.upper()
    box_E9A8A.scale_x = 1.0
    box_E9A8A.scale_y = 1.0
    if not True: box_E9A8A.operator_context = "EXEC_DEFAULT"
    row_A4C66 = box_E9A8A.row(heading='', align=False)
    row_A4C66.alert = False
    row_A4C66.enabled = True
    row_A4C66.active = True
    row_A4C66.use_property_split = True
    row_A4C66.use_property_decorate = False
    row_A4C66.scale_x = 1.0
    row_A4C66.scale_y = 1.0
    row_A4C66.alignment = 'Expand'.upper()
    row_A4C66.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_A4C66.prop(bpy.context.scene, 'sna_resolutions', text='', icon_value=(5 if bpy.context.scene.sna_resolutions else 4), emboss=False)
    row_A4C66.label(text='RESOLUTION', icon_value=192)
    if bpy.context.scene.sna_resolutions:
        col_BA3B1 = box_E9A8A.column(heading='', align=False)
        col_BA3B1.alert = False
        col_BA3B1.enabled = True
        col_BA3B1.active = True
        col_BA3B1.use_property_split = False
        col_BA3B1.use_property_decorate = False
        col_BA3B1.scale_x = 1.2999999523162842
        col_BA3B1.scale_y = 1.059999942779541
        col_BA3B1.alignment = 'Expand'.upper()
        col_BA3B1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_DC98D = col_BA3B1.box()
        box_DC98D.alert = False
        box_DC98D.enabled = True
        box_DC98D.active = True
        box_DC98D.use_property_split = False
        box_DC98D.use_property_decorate = False
        box_DC98D.alignment = 'Expand'.upper()
        box_DC98D.scale_x = 1.0
        box_DC98D.scale_y = 0.6399999856948853
        if not True: box_DC98D.operator_context = "EXEC_DEFAULT"
        box_DC98D.label(text='Aspect Ratio', icon_value=0)
        col_BA3B1.separator(factor=-0.37999987602233887)
        grid_5AF01 = col_BA3B1.grid_flow(columns=6, row_major=False, even_columns=False, even_rows=False, align=True)
        grid_5AF01.enabled = (bpy.context.scene.camera != None)
        grid_5AF01.active = True
        grid_5AF01.use_property_split = False
        grid_5AF01.use_property_decorate = False
        grid_5AF01.alignment = 'Expand'.upper()
        grid_5AF01.scale_x = 1.0
        grid_5AF01.scale_y = 1.0
        if not True: grid_5AF01.operator_context = "EXEC_DEFAULT"
        op = grid_5AF01.operator('sna.my_generic_operator_e6008', text='16:9', icon_value=0, emboss=True, depress=False)
        op = grid_5AF01.operator('sna.my_generic_operator_0ad3c', text='1.35:1', icon_value=0, emboss=True, depress=False)
        op = grid_5AF01.operator('sna.my_generic_operator_7f6d6', text='2.35:1', icon_value=0, emboss=True, depress=False)
        col_BA3B1.separator(factor=0.8200000524520874)
        box_5A125 = col_BA3B1.box()
        box_5A125.alert = False
        box_5A125.enabled = True
        box_5A125.active = True
        box_5A125.use_property_split = False
        box_5A125.use_property_decorate = False
        box_5A125.alignment = 'Expand'.upper()
        box_5A125.scale_x = 1.0
        box_5A125.scale_y = 0.6399999856948853
        if not True: box_5A125.operator_context = "EXEC_DEFAULT"
        box_5A125.label(text='Pixel Rsolutions', icon_value=0)
        row_B05AF = col_BA3B1.row(heading='', align=True)
        row_B05AF.alert = False
        row_B05AF.enabled = True
        row_B05AF.active = True
        row_B05AF.use_property_split = False
        row_B05AF.use_property_decorate = False
        row_B05AF.scale_x = 1.0
        row_B05AF.scale_y = 1.2400000095367432
        row_B05AF.alignment = 'Expand'.upper()
        row_B05AF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_B05AF.prop(bpy.context.scene.render, 'resolution_x', text='', icon_value=0, emboss=True)
        row_B05AF.prop(bpy.context.scene.render, 'resolution_y', text='', icon_value=0, emboss=True)
        col_BA3B1.separator(factor=0.9699999690055847)
        row_B8A1D = col_BA3B1.row(heading='', align=True)
        row_B8A1D.alert = False
        row_B8A1D.enabled = True
        row_B8A1D.active = True
        row_B8A1D.use_property_split = False
        row_B8A1D.use_property_decorate = False
        row_B8A1D.scale_x = 1.0
        row_B8A1D.scale_y = 1.0
        row_B8A1D.alignment = 'Expand'.upper()
        row_B8A1D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_B8A1D.label(text='Passepartout', icon_value=0)
        row_B8A1D.prop(bpy.data.cameras[0], 'passepartout_alpha', text='', icon_value=0, emboss=True)
        col_BA3B1.separator(factor=0.3399999737739563)
        col_BA3B1.popover('RENDER_PT_format_presets', text='Composition Preset', icon_value=4)
        col_BA3B1.separator(factor=0.9699999690055847)
        col_201AD = col_BA3B1.column(heading='', align=False)
        col_201AD.alert = False
        col_201AD.enabled = True
        col_201AD.active = True
        col_201AD.use_property_split = True
        col_201AD.use_property_decorate = False
        col_201AD.scale_x = 0.01000058650970459
        col_201AD.scale_y = 1.0
        col_201AD.alignment = 'Center'.upper()
        col_201AD.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_201AD.prop(bpy.data.scenes[0].view_settings, 'view_transform', text='View Transform', icon_value=0, emboss=True)
        col_201AD.prop(bpy.data.scenes[0].view_settings, 'look', text='Look', icon_value=0, emboss=True)
        col_BA3B1.separator(factor=0.9699999690055847)
        col_8AAC4 = col_BA3B1.column(heading='', align=False)
        col_8AAC4.alert = False
        col_8AAC4.enabled = True
        col_8AAC4.active = True
        col_8AAC4.use_property_split = False
        col_8AAC4.use_property_decorate = False
        col_8AAC4.scale_x = 1.0
        col_8AAC4.scale_y = 1.0
        col_8AAC4.alignment = 'Expand'.upper()
        col_8AAC4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_8AAC4.prop(bpy.data.scenes[0].view_settings, 'exposure', text='Exposure', icon_value=0, emboss=True)
        col_8AAC4.prop(bpy.data.scenes[0].view_settings, 'gamma', text='Gamma', icon_value=0, emboss=True)


class SNA_OT_My_Generic_Operator_7F6D6(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_7f6d6"
    bl_label = "2.35:1"
    bl_description = "1920 x 817 HD "
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        Variable = None
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 817
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_MANACAM_56831(bpy.types.Panel):
    bl_label = 'ManaCam'
    bl_idname = 'SNA_PT_MANACAM_56831'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'ManaCam'
    bl_order = 0
    bl_options = {'HEADER_LAYOUT_EXPAND'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_31187 = layout.box()
        box_31187.alert = False
        box_31187.enabled = True
        box_31187.active = True
        box_31187.use_property_split = False
        box_31187.use_property_decorate = False
        box_31187.alignment = 'Expand'.upper()
        box_31187.scale_x = 1.0
        box_31187.scale_y = 1.0
        if not True: box_31187.operator_context = "EXEC_DEFAULT"
        layout_function = box_31187
        sna_linking_AB941(layout_function, )
        layout_function = box_31187
        sna_camera_controllers_AB710(layout_function, )
        layout_function = box_31187
        sna_camerasettings_6F085(layout_function, )
        layout_function = box_31187
        sna_resolution_843C4(layout_function, )
        layout_function = box_31187
        sna_export__render_F6F8C(layout_function, )


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_button = bpy.props.BoolProperty(name='BUTTON', description='', default=False)
    bpy.types.Scene.sna_camera_setting_toggle = bpy.props.BoolProperty(name='Camera Setting Toggle', description='', default=False)
    bpy.types.Scene.sna_resolutions = bpy.props.BoolProperty(name='Resolutions', description='', default=False)
    bpy.types.Scene.sna_export__render = bpy.props.BoolProperty(name='Export / Render', description='', default=False)
    bpy.types.Scene.sna_display_ffmpeg_properties = bpy.props.BoolProperty(name='Display FFmpeg Properties', description='', default=False)
    bpy.types.Scene.sna_controllers = bpy.props.BoolProperty(name='Controllers', description='', default=False)
    bpy.types.Scene.sna_rename_camera = bpy.props.StringProperty(name='rename camera', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_linking = bpy.props.BoolProperty(name='Linking', description='', default=False)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_0Ad3C)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_E6008)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_7F6D6)
    bpy.utils.register_class(SNA_PT_MANACAM_56831)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_linking
    del bpy.types.Scene.sna_rename_camera
    del bpy.types.Scene.sna_controllers
    del bpy.types.Scene.sna_display_ffmpeg_properties
    del bpy.types.Scene.sna_export__render
    del bpy.types.Scene.sna_resolutions
    del bpy.types.Scene.sna_camera_setting_toggle
    del bpy.types.Scene.sna_button
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_0Ad3C)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_E6008)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_7F6D6)
    bpy.utils.unregister_class(SNA_PT_MANACAM_56831)
